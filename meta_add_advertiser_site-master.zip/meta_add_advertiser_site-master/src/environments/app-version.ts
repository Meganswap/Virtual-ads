export const appVersion = '0.1.0';
