export interface User {
  username?: string,
  accountId: string
}
