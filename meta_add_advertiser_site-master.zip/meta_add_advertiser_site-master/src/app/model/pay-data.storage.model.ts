export interface PayDataStorageModel {
  accountId: string;
  adId: number,
  dateISO: string,
  timeslotFromTimeISO: string,
  creativeId: number,
  playbackId: number
}
