export interface PlaceAdStorageModel {
  accountId: string;
  adId: number,
  dateISO: string,
  timeslotFromTimeISO: string,
  creativeId: number
}
